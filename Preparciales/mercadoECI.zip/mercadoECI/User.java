import java.util.ArrayList;
import java.time.LocalDate;

public class User {
	private int id;
	private String name;
	private String email;
	private LocalDate birthDay;
	private ArrayList<Purchase> purchases;
	private Cart cart;
	private ECIWallet wallet;
	private ArrayList<Post> posts;
	private ArrayList<Product> createdProducts;

}
