import java.util.ArrayList;
import java.time.LocalDateTime;

public class Purchase {
	private String id;
	private LocalDateTime creationDate;
	private String status;
	private User user;
	private ArrayList<Payment> paymentAttempts;
	private ArrayList<PurchaseDetail> details;

}
