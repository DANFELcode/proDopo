public class Payment {
	private double amount;
	private String status;
}
