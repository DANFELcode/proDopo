public class Review {
	private String comment;
	private int score;
}
