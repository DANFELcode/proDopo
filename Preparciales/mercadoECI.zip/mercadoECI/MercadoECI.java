import java.util.Collection;

public class MercadoECI {
    
}
