import java.util.ArrayList;

public class ECIWallet {
	private String id;
	private double balance;
}
