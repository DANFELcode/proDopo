import java.util.ArrayList;

public class Cart {
	private boolean valid;
	private ArrayList<PurchaseDetail> selectedProducts;
}
