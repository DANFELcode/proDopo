public class Product {
	private String id;
	private String name;
	private String category;
	private double price;
	private String description;
	private int stock;
	private User owner;
}
