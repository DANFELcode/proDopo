import java.util.ArrayList;
import java.time.LocalDateTime;


public class Post {
	private String id;
	private LocalDateTime creationDate;
	private String status;
	private String name;
	private Product offeredProduct;
	private ArrayList<Review> reviews;
	private User owner;

}
