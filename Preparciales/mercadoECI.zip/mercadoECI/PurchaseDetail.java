public class PurchaseDetail {
	private int productQuantity;
	private Purchase purchase;
	private Product product;
}
